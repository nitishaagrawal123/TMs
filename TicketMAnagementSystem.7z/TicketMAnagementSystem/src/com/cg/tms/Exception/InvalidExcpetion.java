package com.cg.tms.Exception;

public class InvalidExcpetion extends Exception 
{
	public  InvalidExcpetion()
	{
		super("Wrong Priority");
	}
}
