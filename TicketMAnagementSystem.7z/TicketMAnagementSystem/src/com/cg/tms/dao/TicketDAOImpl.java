package com.cg.tms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketDAOImpl implements TicketDAO 
{
	private Map<String,TicketBean> ticketLog=new HashMap<String,TicketBean>();
	private static Map<String,String> ticketCategory=new HashMap<String,String>();
	private static Map<String,String> getTicketCategoryEntries()
	{
		ticketCategory.put("tc001","software installation");
		ticketCategory.put("tc002","mailbox creation");
		ticketCategory.put("tc003","mailbox issues");
		return ticketCategory;
	}
	

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) 
	{
		
		TicketBean tCategory=ticketLog.put(ticketBean.getTicketNo(),ticketBean);
		if(tCategory==null)
			return true;
		else
			return false;
	}

	@Override
	public List<TicketCategory> listTicketCategory() 
	{
		Map<String,String> map=TicketDAOImpl.getTicketCategoryEntries();

		 List<TicketCategory> list=new ArrayList<TicketCategory>(); 
			
		 for(String ticketId:map.keySet())
		 {
			 TicketCategory tCategory=new TicketCategory(ticketId, map.get(ticketId));
			 list.add(tCategory);
		}
		return list;
	}
}

