package com.cg.tms.ui;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;

import com.cg.tms.Exception.InvalidExcpetion;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI {
	public static void main(String[] args) throws InvalidExcpetion 
	{
		TicketService service=new TicketServiceImpl();
		
		System.out.println("Select ticket category from below list");
		System.out.println("1. Software Installation");
		System.out.println("2. Mailbox Creation");
		System.out.println("3. Mailbox Issues");
		
		List<TicketCategory> list=service.listTicketCategory();
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.print("Enter option");
		int choice1=scanner.nextInt();
		
		String key=list.get(choice1-1).getTicketCategoryId();
		String value=list.get(choice1-1).getCategoryName();
		
		System.out.println("Enter description related to issue");
		
		String desc=scanner.nextLine();
		scanner.next();
		
		System.out.println("Enter priority");
		int choice2=scanner.nextInt();
		
		String priority="";
		if(choice2==1)
			priority="Low";
		else if(choice2==2)
			priority="Medium";
		else if(choice2==3)
			priority="High";
		else
		{
			throw new InvalidExcpetion();
		}
		int rand=(int)(Math.random()*1000);
		
		service.raiseNewTicket(new TicketBean(String.valueOf(rand), new TicketCategory(key,value),desc,priority ,"new","Comments"));
		
		System.out.println("Ticket number "+ rand+"log successfully at "+LocalDateTime.now());
		
	}

}
