package Test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class TicketManagmentSystem_Test {
	int rand=(int) ((Math.random()*1000)+1);
	
	@Before
	public void setUp() {
		System.out.println("Ticket object is set");
	}
	@Test
	public void test() {
		/* fail("Not yet implemented"); */
		TicketService ticketservice=new TicketServiceImpl();
		boolean flag=ticketservice.raiseNewTicket(new TicketBean(String.valueOf(rand), new TicketCategory("tc001","software installation"),"dhhfhd","Medium" , "Newfgjfj", "Abcxshdf"));
		assertTrue(flag);
	}
	@Test
	public void test2() {
		/* fail("Not yet implemented"); */
		TicketService ticketservice=new TicketServiceImpl();
		boolean flag=ticketservice.raiseNewTicket(new TicketBean(String.valueOf(rand), new TicketCategory("tc001","software installation"),"dhhfhd","Medium" , "Newfgjfj", "Abcxshdf"));
		assertTrue(flag);
	}
	@After
	public void tearDown() {
		System.out.println("Ticket object is tear down");
	}

}
